package com.example.reservationapp;

import android.app.Activity;

public class LoginActivity extends Activity {
}
